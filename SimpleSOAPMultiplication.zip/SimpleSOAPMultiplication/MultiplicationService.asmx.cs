
using System.Web.Services;

namespace SimpleSOAPMultiplication
{
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class MultiplicationService : WebService
    {
        [WebMethod]
        public int Multiply(int num1, int num2)
        {
            return num1 * num2;
        }
    }
}
