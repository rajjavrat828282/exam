
using System.Web.Services;

namespace SimpleSOAPSquare
{
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class SquareService : WebService
    {
        [WebMethod]
        public int Square(int number)
        {
            return number * number;
        }
    }
}
