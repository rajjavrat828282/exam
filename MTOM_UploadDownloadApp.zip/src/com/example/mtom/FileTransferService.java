
package com.example.mtom;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;

import javax.activation.DataHandler;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.MTOM;
import javax.xml.ws.soap.MTOMFeature;

@WebService
@MTOM
public class FileTransferService {

    private static final String UPLOAD_DIR = "C:/MTOMUploads/"; // Change path as needed

    @WebMethod
    public String uploadFile(DataHandler fileData, String fileName) {
        try {
            File file = new File(UPLOAD_DIR + fileName);
            try (FileOutputStream out = new FileOutputStream(file)) {
                fileData.writeTo(out);
            }
            return "Upload successful: " + fileName;
        } catch (IOException e) {
            return "Upload failed: " + e.getMessage();
        }
    }

    @WebMethod
    public DataHandler downloadFile(String fileName) {
        try {
            File file = new File(UPLOAD_DIR + fileName);
            return new DataHandler(file.toURI().toURL());
        } catch (Exception e) {
            return null;
        }
    }
}
