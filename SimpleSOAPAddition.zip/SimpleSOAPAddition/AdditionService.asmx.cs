
using System.Web.Services;

namespace SimpleSOAPAddition
{
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class AdditionService : WebService
    {
        [WebMethod]
        public int AddThreeNumbers(int num1, int num2, int num3)
        {
            return num1 + num2 + num3;
        }
    }
}
