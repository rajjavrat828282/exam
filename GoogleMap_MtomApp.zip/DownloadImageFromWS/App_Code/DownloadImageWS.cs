
using System;
using System.ComponentModel;
using System.Web.Services;

namespace DownloadImageFromWS
{
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    public class DownloadImageWS : System.Web.Services.WebService
    {
        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }

        [WebMethod, Description("Get Image Content")]
        public byte[] GetImageFile(string fileName)
        {
            if(System.IO.File.Exists(Server.MapPath("~/Images/") + fileName))
            {
                return System.IO.File.ReadAllBytes(Server.MapPath("~/Images/") + fileName);
            }
            else
            {
                return new byte[] { 0 };
            }
        }

        [WebMethod, Description("Upload Image Content")]
        public string UploadImageFile(byte[] fileBytes, string fileName)
        {
            string filePath = Server.MapPath("~/Images/") + fileName;
            System.IO.File.WriteAllBytes(filePath, fileBytes);
            return "Upload successful!";
        }
    }
}
