
using System;
using System.Web;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        string searchQuery = txtSearch.Text;
        string apiKey = "YOUR_API_KEY_HERE"; // Replace with your actual API Key
        string mapEmbedUrl = $"https://www.google.com/maps/embed/v1/place?key={apiKey}&q={HttpUtility.UrlEncode(searchQuery)}";

        litMap.Text = $"<iframe width='600' height='450' frameborder='0' style='border:0' src='{mapEmbedUrl}' allowfullscreen></iframe>";
    }
}
